﻿Imports System.IO
Imports System.Configuration

Public Class Research

    Private openfile As OpenFileDialog

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Application.Exit()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Reset()

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click

    End Sub

    Private Sub ListBox1_Click(sender As Object, e As EventArgs) Handles ListBox1.Click
        Try
            'set the opendialog properties
            openfile = New OpenFileDialog
            'set allowed file type to open
            openfile.Filter = (".csv")
            'set other properties
            openfile.Title = "Select Files"
            openfile.CheckFileExists = True
            openfile.Multiselect = False
            openfile.RestoreDirectory = False

            If openfile.ShowDialog = Windows.Forms.DialogResult.OK Then
                openfile.SafeFileNames.Count()
                ListFileNames.items.add(openfile.SafeFileNames(1))
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Message, Message Box Buttons.OK, MessaeBoxICONExlcimation")
        End Try

    End Sub

    Private Sub ListBox2_Click(sender As Object, e As EventArgs) Handles ListBox2.Click
        Try
            'set the opendialog properties
            openfile = New OpenFileDialog
            'set allowed file type to open
            openfile.Filter = (".csv")
            'set other properties
            openfile.Title = "Select Files"
            openfile.CheckFileExists = True
            openfile.Multiselect = False
            openfile.RestoreDirectory = False

            If openfile.ShowDialog = Windows.Forms.DialogResult.OK Then
                openfile.SafeFileNames.Count()
                ListFileNames.items.add(openfile.SafeFileNames(1))
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Message, Message Box Buttons.OK, MessaeBoxICONExlcimation")
        End Try

    End Sub

    Private Sub ListBox3_Click(sender As Object, e As EventArgs) Handles ListBox3.Click
        Try
            'set the opendialog properties
            openfile = New OpenFileDialog
            'set allowed file type to open
            openfile.Filter = (".csv")
            'set other properties
            openfile.Title = "Select Files"
            openfile.CheckFileExists = True
            openfile.Multiselect = False
            openfile.RestoreDirectory = False

            If openfile.ShowDialog = Windows.Forms.DialogResult.OK Then
                openfile.SafeFileNames.Count()
                ListFileNames.items.add(openfile.SafeFileNames(1))
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Message, Message Box Buttons.OK, MessaeBoxICONExlcimation")
        End Try

    End Sub

    Private Sub ListBox4_Click(sender As Object, e As EventArgs) Handles ListBox4.Click
        Try
            'set the opendialog properties
            openfile = New OpenFileDialog
            'set allowed file type to open
            openfile.Filter = (".csv")
            'set other properties
            openfile.Title = "Select Files"
            openfile.CheckFileExists = True
            openfile.Multiselect = False
            openfile.RestoreDirectory = False

            If openfile.ShowDialog = Windows.Forms.DialogResult.OK Then
                openfile.SafeFileNames.Count()
                ListFileNames.items.add(openfile.SafeFileNames(1))
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Message, Message Box Buttons.OK, MessaeBoxICONExlcimation")
        End Try

    End Sub

    Private Sub ListBox5_Click(sender As Object, e As EventArgs) Handles ListBox5.Click
        Try
            'set the opendialog properties
            openfile = New OpenFileDialog
            'set allowed file type to open
            openfile.Filter = (".csv")
            'set other properties
            openfile.Title = "Select Files"
            openfile.CheckFileExists = True
            openfile.Multiselect = False
            openfile.RestoreDirectory = False

            If openfile.ShowDialog = Windows.Forms.DialogResult.OK Then
                openfile.SafeFileNames.Count()
                ListFileNames.items.add(openfile.SafeFileNames(1))
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Message, Message Box Buttons.OK, MessaeBoxICONExlcimation")
        End Try

    End Sub
End Class
